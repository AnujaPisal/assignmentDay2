package Utils;

import org.openqa.selenium.WebDriver;

public class TestContext {
    public static WebDriver driver;
}