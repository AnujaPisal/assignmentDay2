
package Pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class calculator_page {

    WebDriver driver;

    public calculator_page(WebDriver driver1) {
        driver = driver1;
        driver.get("https://www.calculator.net/bmi-calculator.html");
        driver.manage().window().maximize();
    }

    void enterage(String n) {
        WebElement button = driver.findElement(By.className("clearbtn"));
        button.click();
        driver.findElement(By.id("cage")).sendKeys(n);
    }

    void enterheight(String m) {
        driver.findElement(By.name("cheightmeter")).sendKeys(m);
    }

    void enterweight(String o) {
        driver.findElement(By.name("ckg")).sendKeys(o);
        driver.findElement(By.xpath("//input[@type='image']")).click();
    }



    String getresult()
    {
        String actual = driver.findElement(By.tagName("b")).getText().trim();
        return actual;
    }

    public String calculate(String n, String m, String o) {

        //   driver.findElement(By.id("cage")).sendKeys(n);

        // driver.findElement(By.name("cheightmeter")).sendKeys(m);
        //driver.findElement(By.name("ckg")).sendKeys(o);
        //  driver.findElement(By.xpath("//input[@type='image']")).click();
        //String actual = driver.findElement(By.tagName("b")).getText().trim();
        //return actual;

       // enternumber();
        enterage(n);
        enterheight(m);
        enterweight(o);
        //void click = calculate();
        String actual = getresult();
        return actual;
    }

}
