
package Steps;

        import Pages.calculator_Page;
        import Utils.TestContext;
        import io.github.bonigarcia.wdm.WebDriverManager;
        import org.openqa.selenium.WebDriver;
        import org.openqa.selenium.chrome.ChromeDriver;
        import org.testng.Assert;
        import org.testng.annotations.BeforeMethod;

public class Calculator_Steps extends TestContext {
    calculator_Page calculatorPage;

    @io.cucumber.java.en.Given("I am on calculator page")
    public void iAmOnCalculatorPage() {

        calculatorPage=new CalculatorPage(driver);
    }

    @io.cucumber.java.en.When("I press clear button")
    public void iPressClearButton() {
        calculatorPage.resetCalculator();

    }

    @io.cucumber.java.en.And("I enter age as {string}")
    public void iEnterAgeAsInCalculator(String age) {
        calculatorPage.enterAge(age);
    }

    @io.cucumber.java.en.And("I enter height as {string}")
    public void iEnterHeightAsInCalculator(String height) {
        calculatorPage.enterHeight(height);
    }

    @io.cucumber.java.en.And("I enter weight as {string}")
    public void iEnterWeightAsInCalculator(String weight) {
        calculatorPage.enterWeight(weight);
    }

    @io.cucumber.java.en.And("I press calculate button")
    public void iPressCalculateButton() {
        calculatorPage.clickCalculateBtn();
    }

    @io.cucumber.java.en.Then("I see result as {string}")
    public void iSeeResultAs(String expectedResult) {
        Assert.assertEquals(calculatorPage.getResult(),expectedResult);
    }
}